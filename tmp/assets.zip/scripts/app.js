console.log('app.js');
