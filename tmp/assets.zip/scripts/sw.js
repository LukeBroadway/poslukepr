// This file will be available under root domain.
// https://example.com/sw.js